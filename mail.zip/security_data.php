<?php

// security data for mail
$mail_host = 'smtp.office365.com';
$mail_user = 'alain_niessen@hotmail.com';
$mail_pw   = 'pbE9wDGU';